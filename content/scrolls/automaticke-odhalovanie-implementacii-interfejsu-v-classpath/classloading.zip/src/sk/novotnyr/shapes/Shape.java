package sk.novotnyr.shapes;

public interface Shape {
	public double getArea(); 
}
