package sk.novotnyr.shapes;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimerTask;

import javax.swing.JList;

public class RefreshClassesAction extends TimerTask {
	/**
	 * Komponent Zoznam, ktory bude aktualizovany
	 */
	private JList jList;

	/**
	 * Odhalovac implementacii
	 */
	private ShapeDiscoverer discoverer = new ShapeDiscoverer();
	
	public RefreshClassesAction(JList list) {
		super();
		this.jList = list;
	}

	/**
	 * Aktualizuje zoznam na zaklade novonajdenych tried
	 */
	public void run() {
		jList.setListData(discoverer.discover().toArray());
	}

}
