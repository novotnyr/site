package sk.novotnyr.shapes;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Logger;

public class ShapeDiscoverer {
	public static final Logger logger = Logger.getLogger(ShapeDiscoverer.class.getName());
	
	public static final String PROPERTY_KEY = "java.class.path";

	public static final String CLASS_EXTENSION = ".class";
	
	public static final String PACKAGE_NAME = "sk.novotnyr.shapes";
	
	public static final String PACKAGE_DIRECTORY_NAME = PACKAGE_NAME.replace(".", "/");
	
	/**
	 * Vrati nazov triedy zo suboru ukazujuceho na CLASS subor.
	 * <p>
	 * Priklad: Pre <tt>D:\projects\java\classez\bin\sk\novotnyr\shapes\Circle.class</tt> 
	 * vrati <tt>Circle</tt>
	 * @param file subor obsahujuci nazov a cestu ku CLASS suboru
	 * @return nazov triedy
	 */
	protected String getClassNameFromFile(File file) {
		if(file.getName().endsWith(CLASS_EXTENSION)) {
			return PACKAGE_NAME + "." + file.getName().substring(0, file.getName().length() - CLASS_EXTENSION.length());
		} else {
			return null;
		}
	}
	
	/**
	 * Zisti vsetky triedy implementujuce dane rozhranie
	 * v strukture balickov zacinajucej v adresari zadanom v parametri.
	 * <p>
	 *  
	 * @param aPath cesta k adresaru v ktorom zacina balickova struktura. Musi 
	 * to byt adresar (JAR subory a pod su ignorovane). 
	 */
	protected List<Class> findClassNames(String aPath) {
		if(aPath == null || aPath.trim().length() == 0) {
			return new ArrayList<Class>();
		}
		List<Class> classes = new ArrayList<Class>();
		
		File path = new File(aPath);
		if(path.isDirectory()) {
			File packageFile = new File(path, PACKAGE_DIRECTORY_NAME);
			for (File f : packageFile.listFiles()) {
				String className = getClassNameFromFile(f);
				if(className != null) {
					try {
						Class clazz = Class.forName(className);
						if(Shape.class.isAssignableFrom(clazz)) {
							classes.add(clazz);
						}
					} catch (ClassNotFoundException e) {
						logger.severe("Cannot instantiate " + className);
					}
				}
			}
		}
		return classes;
	}
	
	/**
	 * Vrati zoznam tried implementujucich Shape z CLASSPATH.
	 * <p>
	 * Prelezie sa zoznam z hodnoty systemovej premennej v {@link ShapeDiscoverer#PROPERTY_KEY}
	 * a kazda polozka reprezentujuca adresar sa prehlada pre triedy.
	 * 
	 */
	public List<Class> discover() {
		String javaClasspath = System.getProperty(PROPERTY_KEY);
		if(javaClasspath == null) {
			throw new IllegalArgumentException(PROPERTY_KEY + " not found in system properties.");
		}
		String[] paths = javaClasspath.split(File.pathSeparator);
		
		List<Class> classes = new ArrayList<Class>();
		for (String path : paths) {			
			classes.addAll(findClassNames(path));
		}
		return classes;
	}
	
	public static void main(String[] args) throws Exception {
		ShapeDiscoverer d = new ShapeDiscoverer();

		List<Class> classes = d.discover();
		for (Class class1 : classes) {
			System.out.println(class1);
		}
	}
}
