package sk.novotnyr.shapes;

public class Circle implements Shape {
	private double diameter = 1;
	
	public double getArea() {
		return Math.PI * (diameter * diameter);
	}
	
}
