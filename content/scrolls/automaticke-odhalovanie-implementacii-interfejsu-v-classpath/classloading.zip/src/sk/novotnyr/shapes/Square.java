package sk.novotnyr.shapes;

public class Square implements Shape {
	private double size = 1;

	public double getArea() {
		return size * size;
	}	
}
