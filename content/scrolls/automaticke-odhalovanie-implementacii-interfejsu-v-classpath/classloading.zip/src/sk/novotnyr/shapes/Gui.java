package sk.novotnyr.shapes;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Timer;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;

public class Gui {
	public static void main(String[] args) {
		JFrame frame = new JFrame("GUI");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container cp = frame.getContentPane();
		
		final JList list = new JList(new String[] {"Test", "test", "TEST"});
		cp.add(list, BorderLayout.CENTER);
		
		JButton button = new JButton("Go!");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Class clazz = (Class) list.getSelectedValue();
				try {
					Shape shape = (Shape) clazz.newInstance();
					System.out.println(shape.getArea());
				} catch (Exception e1) {
					System.out.println("Cannot instantiate the selected class " + clazz);
				} 
			}			
		});
		cp.add(button, BorderLayout.SOUTH);
		
		frame.pack();
		frame.setVisible(true);
		
		Timer timer = new Timer();
		RefreshClassesAction action = new RefreshClassesAction(list);
		timer.schedule(action, 0, 3000);
		
	}
}
