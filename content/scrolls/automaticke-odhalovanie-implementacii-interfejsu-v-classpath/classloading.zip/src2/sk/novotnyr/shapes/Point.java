package sk.novotnyr.shapes;

public class Point implements Shape {

	public double getArea() {
		return 0;
	}
	
}
