package exchangerates;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.concurrent.TimeUnit;

import thinlet.FrameLauncher;
import thinlet.Thinlet;

public class ExchangeRateForm extends Thinlet {
	
	private Object aboutBox;

	public ExchangeRateForm() {
		try {
			add(parse(getClass().getSimpleName() + ".xml"));
			aboutBox = parse("AboutBox.xml");
			
			loadExchangeRates("USD");
			
		} catch (IOException e) {
			throw new IllegalStateException("Illegal or missing form definition.", e);
		}
	}
	
	public void loadExchangeRates(String currencyCode) {
		try {
			ExchangeRateService service = new ExchangeRateService();
			BigDecimal currentExchange = service.getCurrentExchange(currencyCode);
			if(currentExchange != null) {
				setExchangeRateText(currentExchange.toString());
			}
		
		} catch (CurrencyException e) {
			e.printStackTrace();
		}
	}
	
	public void setExchangeRateText(String exchangeRate) {
		setString(find("exchangeRate"), "text", exchangeRate);
	}
	
	public void showAboutBox() {
		add(aboutBox);
	}
	
	public void closeAboutBox() {
		remove(aboutBox);
	}	
	
	public static void main(String[] args) {
		FrameLauncher frameLauncher = new FrameLauncher("Exchange Rate", new ExchangeRateForm(), 800, 600);
		frameLauncher.pack();
	}
}
