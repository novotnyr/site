package exchangerates;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.LinkedList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class ExchangeRateService {
	public BigDecimal getCurrentExchange(String currencyCode) throws CurrencyException {
		String urlString = "http://www.ecb.europa.eu/stats/eurofxref/eurofxref-daily.xml";
		try {
			InputStream in = new URL(urlString).openStream();
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			Document document = documentBuilderFactory.newDocumentBuilder().parse(in);
			
			NodeList cubeElements = document.getElementsByTagName("Cube");
			BigDecimal result = null;
			for(int i = 0; i < cubeElements.getLength(); i++) {
				Element cubeElement = (Element) cubeElements.item(i);
				if(currencyCode.equals(cubeElement.getAttribute("currency"))) {
					result = new BigDecimal(cubeElement.getAttribute("rate"));
					return result;
				}
			}			
			return result;			
		} catch (MalformedURLException e) {
			throw new CurrencyException("Illegal URL for currency service: " + urlString, e);
		} catch (IOException e) {
			throw new CurrencyException("I/O error while retrieving currency rates data " + e.getMessage(), e);
		} catch (SAXException e) {
			throw new CurrencyException("Error while parsing XML response from server: " + e.getMessage(), e);
		} catch (ParserConfigurationException e) {
			throw new CurrencyException("Error while configuring response parser from server: " + e.getMessage(), e);
		} catch (NumberFormatException e) {
			throw new CurrencyException("Exchange rate is not a string.");
		}
	}
	
	public List<ExchangeRate> getHistory(String currencyCode) throws CurrencyException {
		List<ExchangeRate> exchangeRates = new LinkedList<ExchangeRate>();
		
		String urlString = "http://www.ecb.europa.eu/stats/eurofxref/eurofxref-hist-90d.xml";
		try {
			InputStream in = new URL(urlString).openStream();
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			Document document = documentBuilderFactory.newDocumentBuilder().parse(in);
			
			NodeList nodeList = (NodeList) XPathFactory.newInstance().newXPath().evaluate("//*[@currency='CZK']/@rate", document, XPathConstants.NODESET);
			for(int i = 0; i < nodeList.getLength(); i++) {
				Node node = nodeList.item(i);
				// node has type org.w3c.dom.Attr
				String exchangeRateValue = node.getNodeValue();
				Node dailyCubeNode = ((Attr) node).getOwnerElement().getParentNode();
				String date = dailyCubeNode.getAttributes().getNamedItem("time").getNodeValue();
				
				exchangeRates.add(new ExchangeRate(currencyCode, date, exchangeRateValue));
			}
			
			return exchangeRates;			
		} catch (MalformedURLException e) {
			throw new CurrencyException("Illegal URL for currency service: " + urlString, e);
		} catch (IOException e) {
			throw new CurrencyException("I/O error while retrieving currency rates data " + e.getMessage(), e);
		} catch (SAXException e) {
			throw new CurrencyException("Error while parsing XML response from server: " + e.getMessage(), e);
		} catch (ParserConfigurationException e) {
			throw new CurrencyException("Error while configuring response parser from server: " + e.getMessage(), e);
		} catch (NumberFormatException e) {
			throw new CurrencyException("Exchange rate is not a string.");
		} catch (XPathExpressionException e) {
			throw new CurrencyException("Syntax error in XPath expression.", e);
		}				
	}
	
	public static void main(String[] args) throws Exception {
		ExchangeRateService service = new ExchangeRateService();
//		BigDecimal exchange = service.getCurrentExchange("USD");
//		System.out.println(exchange);
		System.out.println(service.getHistory("USD"));
	}
}
