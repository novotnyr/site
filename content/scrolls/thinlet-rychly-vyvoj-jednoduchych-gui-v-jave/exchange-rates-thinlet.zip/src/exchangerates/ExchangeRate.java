package exchangerates;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Currency;
import java.util.Date;

public class ExchangeRate {
	private String currencyCode;
	
	private Date date;
	
	private BigDecimal rate;

	public ExchangeRate(String currencyCode, String date, String rate) {
		this(currencyCode, (Date) null, (BigDecimal) null);
		try {
			this.date = new SimpleDateFormat("yyyy-MM-dd").parse(date);
			this.rate = new BigDecimal(rate);
		} catch (ParseException e) {
			throw new IllegalArgumentException("Incorrect date format for date " + date + ". Use yyyy-MM-dd syntax.", e);
		}
	}

	public ExchangeRate(String currencyCode, Date date, BigDecimal rate) {
		super();
		this.currencyCode = currencyCode;
		this.date = date;
		this.rate = rate;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public Date getDate() {
		return date;
	}

	public BigDecimal getRate() {
		return rate;
	}

	@Override
	public String toString() {
		return "ExchangeRate [currencyCode=" + currencyCode + ", rate=" + rate
				+ ", date=" + date + "]";
	}
	
}
